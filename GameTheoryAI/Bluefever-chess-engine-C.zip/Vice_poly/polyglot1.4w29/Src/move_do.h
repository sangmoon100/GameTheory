
// move_do.h

#ifndef MOVE_DO_H
#define MOVE_DO_H

// includes

#include "board.h"
#include "util.h"

// functions

extern void move_do (board_t * board, int move);

#endif // !defined MOVE_DO_H

// end of move_do.h

