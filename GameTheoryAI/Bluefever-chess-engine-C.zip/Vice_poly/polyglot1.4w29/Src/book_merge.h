
// book_merge.h

#ifndef BOOK_MERGE_H
#define BOOK_MERGE_H

// includes

#include "util.h"

// functions

extern void book_merge (int argc, char * argv[]);

#endif // !defined BOOK_MERGE_H

// end of book_merge.h

