import pyximport
pyximport.install()

from .reversi_solver_cython import *
